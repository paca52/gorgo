#include "raylib.h"
#include <stdlib.h>

const int ScreenHeight = 720;
const int ScreenWidth = 1024;

typedef struct enemy{
    float x, y;
    int is_alive;
    struct enemy *sledeci;
}enemy;

typedef struct bullet{
    float x, y, speed_x, speed_y;
    int is_alive;
    struct bullet *sledeci;
}bullet;

typedef struct tacka{
    float x, y;
}tacka;

void dodaj(bullet **poc, bullet **kraj, tacka pos){
    bullet *new = (bullet*)malloc(sizeof(bullet));
    new->is_alive = 1;
    new->x = pos.x + 16;
    new->y = pos.y + 16;
    new->speed_x = -1;
    new->speed_y = -1;
    new->sledeci = NULL;
    if(*poc == NULL)
        *poc = new;
    else
        (*kraj)->sledeci = new;
    *kraj = new;
}

void dodaj_e(enemy **poc, enemy **kraj){
    enemy *new = (enemy*)malloc(sizeof(enemy));
    new->is_alive = 1;
    new->x = GetRandomValue(20, ScreenWidth-20);
    new->y = GetRandomValue(20, ScreenHeight-20);
    new->sledeci = NULL;
    if(*poc == NULL)
        *poc = new;
    else
        (*kraj)->sledeci = new;
    *kraj = new;
}

void remove(bullet **poc, bullet *tmp){
    if(tmp == *poc){
        if (*poc != NULL){
            if ((*poc)-> sledeci == NULL){
                *poc = NULL;
                free(*poc);
            }
            else{
                bullet* tmp = *poc;
                *poc = (*poc)-> sledeci;
                if(tmp != NULL)
                    free(tmp);
            }
        }
    }
    else{
        bullet *tek = *poc;
        while(tek->sledeci != tmp)
            tek = tek->sledeci;
        tek->sledeci = tmp->sledeci;
        free(tmp);
    }
}

void remove_e(enemy **poc, enemy *tmp){
    if(tmp == *poc){
        if (*poc != NULL){
            if ((*poc)-> sledeci == NULL){
                *poc = NULL;
                free(*poc);
            }
            else{
                enemy* tmp = *poc;
                *poc = (*poc)-> sledeci;
                free(tmp);
            }
        }
    }
    else{
        enemy *tek = *poc;
        while(tek->sledeci != tmp)
            tek = tek->sledeci;
        tek->sledeci = tmp->sledeci;
        if(tmp != NULL)
            free(tmp);
    }
}

int len(bullet *poc){
    bullet *tek = poc;
    int br = 0;
    while(tek != NULL){
        tek = tek->sledeci;
        br++;
    }

    return br;
}

int main(){
    //screen & fps
    InitWindow(ScreenWidth, ScreenHeight, "floy kil v1.1");
    SetTargetFPS(60);
    Image icon = LoadImage("./images/player_left.png");
    SetWindowIcon(icon);

    //loading textures
    Texture2D menu = LoadTexture("./images/menu.png"), player_left = LoadTexture("./images/player_left.png"), nep = LoadTexture("./images/cigan.png");
    Texture2D player_right = LoadTexture("images/player_right.png"), player_up = LoadTexture("images/player_up.png"), player_down = LoadTexture("images/player_down.png");

    //PENDING NIGGA
    Texture2D win = LoadTexture("./images/win_screen.png");
    
    tacka pos;
    pos.x = ScreenWidth/2;
    pos.y = ScreenHeight/2;
    player_down.width *= 2; player_up.width *= 2; player_right.width *= 2; player_left.width *= 2;
    player_down.height *= 2; player_left.height *= 2; player_right.height *= 2; player_up.height *= 2;

    //game loop
    int c = 0, lvl = 1, init = 0, sum = 0, ammo = 10;
    float timer = 0;
    char last_key_pressed = 'a';
    enemy *a_poc = NULL, *a_kraj = NULL;

        //bullets
        bullet *poc = NULL, *kraj = NULL;
        int bull_cout = 0;

    while(!WindowShouldClose()){

        if(lvl == 5){
            BeginDrawing();
            ClearBackground(GRAY);
            DrawTexture(win, 0, 0, WHITE);
            DrawText("u win, no more gorg floy\nesc to exet", ScreenWidth/2, ScreenHeight/2, 30, GREEN);
            EndDrawing();
        }
        else{

            //menu
            if(c != 257){
                BeginDrawing();

                ClearBackground(BLACK);
                DrawTexture(menu, 0, 0, WHITE);
                c = GetKeyPressed();

                EndDrawing();
            }
            //game
            else{
                
                //ako je init = 0, spawnuj ememy, u sup. preskoci ovaj for
                if(init == 0){
                    for(int i=0; i<lvl*2; i++)
                        dodaj_e(&a_poc, &a_kraj);
                    init = 1;
                }
                timer += GetFrameTime();
                //movement
                int w = IsKeyDown(KEY_W), a = IsKeyDown(KEY_A), s = IsKeyDown(KEY_S), d = IsKeyDown(KEY_D);
                if(w && d){
                    last_key_pressed = 'e';
                    pos.y -= 3.0f;
                    pos.x += 3.0f;
                }
                else if(w && a){
                    last_key_pressed = 'q';
                    pos.y -= 3.0f;
                    pos.x -= 3.0f;
                }
                else if(s && d){
                    last_key_pressed = 'c';
                    pos.y += 3.0f;
                    pos.x += 3.0f;
                }
                else if(s && a){
                    last_key_pressed = 'z';
                    pos.y += 3.0f;
                    pos.x -= 3.0f;
                }
                else if(s && w){}
                else if(w){
                    pos.y -= 3.0f;
                    last_key_pressed = 'w';
                }
                else if(s){
                    pos.y += 3.0f;
                    last_key_pressed = 's';
                }
                else if(d){
                    last_key_pressed = 'd';
                    pos.x += 3.0f;
                }
                else if(a){
                    last_key_pressed = 'a';
                    pos.x -= 3.0f;
                }
                    
                //drawing
                BeginDrawing();

                ClearBackground(GRAY);
                switch(last_key_pressed){
                    case 'w': case 'e': case 'q':
                        DrawTexture(player_up, pos.x, pos.y, WHITE);
                        break;
                    case 'd':
                        DrawTexture(player_right, pos.x, pos.y, WHITE);
                        break;
                    case 'a':
                        DrawTexture(player_left, pos.x, pos.y, WHITE);
                        break;
                    case 's': case 'z': case 'c':
                        DrawTexture(player_down, pos.x, pos.y, WHITE);
                        break;
                }
                DrawText(TextFormat("Ammo: %d\nnum of bulls in list: %d\ntimer: %.2f", ammo-bull_cout, len(poc), timer), 10, 10, 20, GREEN);

                //enemy render and bullet collision
                bullet *tmp = poc;
                enemy *tek = a_poc;
                sum = 0;
                if(tmp != NULL && tek != NULL){
                    while(tek != NULL){
                        tmp = poc;
                        while(tmp != NULL){
                            if(tek == NULL)
                                break;
                            if(tmp->y >= tek->y && tmp->y <= tek->y + nep.height && tmp->x >= tek->x && tmp->x <= tek->x + nep.width){
                                tek->is_alive = 0;
                                bullet *a = tmp;
                                enemy *b = tek;
                                tek = tek->sledeci;
                                tmp = tmp->sledeci;
                                remove(&poc, a);
                                remove_e(&a_poc, b);
                                bull_cout--;
                            }
                            else
                                tmp = tmp->sledeci;
                        }
                        if(tek!=NULL)
                            tek = tek->sledeci;
                    }
                }

                for(tek = a_poc; tek; tek=tek->sledeci){
                    if(tek->is_alive){
                        DrawTexture(nep, tek->x, tek->y, WHITE);
                        DrawRectangle(tek->x, tek->y, 1, 1, RED);
                    }
                    sum += tek->is_alive;
                }
                
                if(sum == 0){
                    init = 0;
                    lvl++;
                }
                
                //sklanjanje prvog metka ako je ispao s mape
                if(poc != NULL)
                    if(poc->x >= ScreenWidth || poc->x <= 0 || poc->y <= 0 || poc->y >= ScreenHeight){
                        remove(&poc, poc);
                        bull_cout--;
                    }

                //pomeranje metaka
                tmp = poc;

                while(tmp != NULL){
                    if(tmp->is_alive){
                        DrawRectangle(tmp->x, tmp->y, 5, 5, RED);
                        tmp->x += tmp->speed_x;
                        tmp->y += tmp->speed_y;
                    }
                    tmp = tmp->sledeci;
                }

                //pravljenje metaka
                if(IsKeyPressed(KEY_K) && bull_cout < ammo){
                    dodaj(&poc, &kraj, pos);
                    if(kraj->speed_x == -1 || kraj->speed_y == -1){
                        switch (last_key_pressed){
                            case 'w':
                                kraj->speed_y = -4.4f;
                                kraj->speed_x = 0;
                                break;
                            case 'a':
                                kraj->speed_y = 0;
                                kraj->speed_x = -4.4f;
                                break;
                            case 's':
                                kraj->speed_y = 4.4f;
                                kraj->speed_x = 0;
                                break;
                            case 'd':
                                kraj->speed_y = 0;
                                kraj->speed_x = 4.4f;
                                break;
                            case 'q':
                                kraj->speed_y = -4.4f;
                                kraj->speed_x = -4.4f;
                                break;
                            case 'e':
                                kraj->speed_y = -4.4f;
                                kraj->speed_x = 4.4f;
                                break;
                            case 'z':
                                kraj->speed_y = 4.4f;
                                kraj->speed_x = -4.4f;
                                break;
                            case 'c':
                                kraj->speed_y = 4.4f;
                                kraj->speed_x = 4.4f;
                        }
                    }
                    bull_cout++;
                }

                DrawFPS(10, 700);

                EndDrawing();
            }
        }
    }

    CloseWindow();
    return 0;
}